// components/AppInitializer.tsx
"use client";
import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getDecodedUser, fetchUser } from '../lib/user';

export default function AppInitializer({ children }: { children: React.ReactNode }) {
  // 1. JWT에서 최소 정보 빠르게 decode
  const decodedUser = getDecodedUser();

  // 2. 최신 정보는 react-query로 fetch
  const { data: user, isLoading, error } = useQuery({
    queryKey: ['user'],
    queryFn: fetchUser,
    enabled: !!decodedUser,
    retry: false,
    staleTime: 1000 * 60,
  });

  useEffect(() => {
    if (error) {
      // 401 등 인증 실패 시
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
  }, [error]);
    useEffect(() => {
      if (!decodedUser) {
        window.location.href = '/login';
      }
    }, [decodedUser]);

  // 앱 전체를 감싸서 user 상태를 하위에 전달
  // (Context로 감싸거나, 필요에 따라 prop drilling 등)
  return (
    <>
      {children}
    </>
  );
}
