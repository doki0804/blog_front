'use client'

import { notFound } from 'next/navigation'
import axios from '@/lib/axios'
import { useQuery } from '@tanstack/react-query'
import Link from 'next/link'

export type Post = {
  id: number
  title: string
  author: { nickname: string }
  created_at: string
}

export type Tab = {
  id: number
  name: string
}

export default function TabPostsPage({ params }: { params: { id: string } }) {
  const tabId = parseInt(params.id)

  // 탭 목록 패칭 (react-query)
  const {
    data: tabs = [],
    isLoading: isTabsLoading,
    error: tabsError,
  } = useQuery<Tab[]>({
    queryKey: ['tabs'],
    queryFn: async () => {
      const res = await axios.get('/tabs')
      return res.data
    },
    staleTime: 1000 * 60,
  })

  // 탭 선택 (탭 없으면 notFound로)
  const tab = tabs.find((t) => t.id === tabId)

  // 게시글 패칭 (tab이 존재할 때만)
  const {
    data: posts = [],
    isLoading: isPostsLoading,
    error: postsError,
  } = useQuery<Post[]>({
    queryKey: ['posts', 'tab', tabId],
    queryFn: async () => {
      const res = await axios.get(`/tabs/${tabId}/posts`)
      return res.data
    },
    enabled: !!tab, // tab이 없을 때는 fetch 안함
    staleTime: 1000 * 60,
  })

  // 에러 핸들링
  if (isTabsLoading) return <p>탭 정보를 불러오는 중...</p>
  if (tabsError) return <p>탭 정보를 불러오는 데 실패했습니다.</p>
  if (!tab) return notFound()
  if (isPostsLoading) return <p>게시글을 불러오는 중...</p>
  if (postsError) return <p>게시글을 불러오는 데 실패했습니다.</p>

  return (
    <section className="space-y-4">
      <h1 className="text-2xl font-bold">{tab.name} 게시글</h1>

      {posts.length === 0 ? (
        <p>게시글이 없습니다.</p>
      ) : (
        <ul className="space-y-2">
          {posts.map((post) => (
            <li key={post.id} className="border p-4 rounded">
              <Link href={`/posts/${post.id}`} className="text-xl font-semibold hover:underline">
                {post.title}
              </Link>
              <div className="text-sm text-gray-500">
                by {post.author.nickname} • {new Date(post.created_at).toLocaleString()}
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}