'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { getDecodedUser } from '@/lib/user'
import TabManager from '@/components/TabManager'

export default function AdminTabPage() {  
  const user = getDecodedUser()
  const router = useRouter()

  useEffect(() => {
    if (user && !user.is_admin) {
      alert('관리자만 접근할 수 있습니다.') // ✅ 추가됨
      router.replace('/') // ✅ 홈으로 강제 이동
    }
  }, [user])

  if (!user || !user.is_admin) return null

  return <TabManager />
}
